const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Session = require('../models/Session');

// Public sessions
router.get('/', async (req, res) => {
  const sessions = await Session.find({ status: 'published' }).sort({ updated_at: -1 }).limit(50);
  res.json(sessions);
});

// User's sessions (draft+published)
router.get('/my-sessions', auth, async (req, res) => {
  const sessions = await Session.find({ user_id: req.user.id }).sort({ updated_at: -1 });
  res.json(sessions);
});

router.get('/my-sessions/:id', auth, async (req, res) => {
  const s = await Session.findById(req.params.id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  if (s.user_id.toString() !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  res.json(s);
});

// Create or update draft
router.post('/my-sessions/save', auth, async (req, res) => {
  const { id, title, description, type, date, json_file_url, status } = req.body;
  if (id) {
    const s = await Session.findById(id);
    if (!s) return res.status(404).json({ error: 'Not found' });
    if (s.user_id.toString() !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
    Object.assign(s, { title, description, type, date, json_file_url, status: status || s.status });
    await s.save();
    return res.json(s);
  } else {
    const newS = await Session.create({ user_id: req.user.id, title, description, type, date, json_file_url, status: status || 'draft' });
    return res.json(newS);
  }
});

// Publish
router.post('/my-sessions/publish', auth, async (req, res) => {
  const { id } = req.body;
  const s = await Session.findById(id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  if (s.user_id.toString() !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  s.status = 'published';
  await s.save();
  res.json(s);
});

module.exports = router;
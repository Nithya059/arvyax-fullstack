// routes/auth.js
import express from "express";
const router = express.Router();

// Example in-memory users (replace with DB later)
let users = [];

router.post("/register", (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const exists = users.find((u) => u.email === email);
  if (exists) {
    return res.status(400).json({ error: "Email already registered" });
  }

  const newUser = { id: Date.now(), name, email };
  users.push(newUser);

  res.json({ ok: true, user: newUser });
});

export default router;